/* (c) Ricardas Cepas <rch@pub.osf.lt>. Copying policy: BSD or GNU GPL V2. */
#include <stdlib.h>
#include <stdio.h>

extern int testUTF8 (void);

main ()
{
  unsigned int x;

  x = testUTF8 ();
  switch (x)
    {
    case 1:
      x = 0;
      fprintf (stderr, "UTF-8 unicode mode \n");
      break;
    case 0:
      x = 1;
      fprintf (stderr, "Old single byte char mode \n");
      break;
    case 127:
      fprintf (stderr, "Not a tty !\n");
      break;
    default:
      fprintf (stderr, "Error %i \n", x);
    }
  exit (x);			/*0 - unicode, 1 - not */
}
