#include <locale.h>
main () {
  	int i;
	
	printf("setlocale (LC_ALL, \"\") returns %s\n",setlocale (LC_ALL, ""));
	printf("setlocale (LC_COLLATE, \"\") returns %s\n",setlocale (LC_COLLATE, ""));
	printf("setlocale (LC_CTYPE, \"\") returns %s\n",setlocale (LC_CTYPE, ""));
	printf("setlocale (LC_MESSAGES, \"\") returns %s\n",setlocale (LC_MESSAGES, ""));
	printf("setlocale (LC_MONETARY, \"\") returns %s\n",setlocale (LC_MONETARY, ""));
	printf("setlocale (LC_NUMERIC, \"\") returns %s\n",setlocale (LC_NUMERIC, ""));
	printf("setlocale (LC_TIME, \"\") returns %s\n",setlocale (LC_TIME, ""));

	for (i=1; i<=0x400; i++) {
	  printf("isprint(%i:%c)=%i; toupper()=%c; tolower()=%c; \n", i, (char) i, isprint(i), toupper(i), tolower(i));
	}
  
}
