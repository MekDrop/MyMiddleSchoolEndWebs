#!/bin/sh
# © Ričardas Čepas <rch@WriteMe.Com>.  Copying policy: Berkeley style.
#set -x
localXfontsdir=/usr/local/lib/X11/fonts
Xbasedir=/usr/X11R6
bindir=/usr/local/bin
# install files with this ownership:
owner=root
group=staff

bold () {
	tput bold || tput md
	printf "$*"
	tput sgr0 || tput me
}


install_prompt () {
	if test ! -e "$4" || cmp -s "$3" "$4"; then
		a='y'
	else
		ls -l "$3" "$4"
		bold "$4 already exists, overwrite? [Y/n]" && read a e
	fi
	if [ "${a#[Nn]}" = "$a" ]; then
	    mv -f "$4"  "$4".old 2>/dev/null
	    install -c $install_own "$1" "$2" "$3" "$4"
	fi
}

BASE_DIR="`pwd`/`dirname $0`"

installFreeBSD4 () {
	LOCALEDIR=${DESTDIR}/usr/share/locale
	mtree -deU -f BSD/BSD.usr.share.dist -p ${DESTDIR}/usr/share
	mtree -deU -f BSD/BSD.usr.local.share.nls.dist -p ${DESTDIR}/usr/local/share/nls
	if test -e "$LOCALEDIR/lt_LT.UTF-8/LC_TIME"; then
		bold "lt_LT.UTF-8 locale already exists, overwrite? [Y/n]" && read a e
	else
		a='y'
	fi
	if [ "${a#[Nn]}" = "$a" ]; then
	    ln -fs ../la_LN.ASCII/LC_COLLATE ${LOCALEDIR}/lt_LT.UTF-8/LC_COLLATE
	    mklocale -o ${LOCALEDIR}/lt_LT.UTF-8/LC_CTYPE BSD/src/usr.bin/mklocale/data/lt_LT.UTF-8.src
	    grep -v '^#' <BSD/src/share/timedef/data/lt_LT.UTF-8.src.new >${LOCALEDIR}/lt_LT.UTF-8/LC_TIME
	fi
}

test "`whoami`" = "root" || { bold 'Type "su" and run this as root!\n'; exit 3; }
test "${PATH%%*/sbin*}" = "" || { bold 'Check that your PATH variable has /sbin,/usr/sbin and X (normaly /usr/X11R6/bin) directories !\n'; exit 4; }
#set -o errexit;
for group in "$group" wheel staff bin root; do
    if install -d -g "$group" ./tstdir; then
	  Group="$group"; export Group
	  rmdir ./tstdir
	  break
    fi
done
install_own="-o $owner -g $Group"

backup="$BASE_DIR/../backup/backup.tar"
export backup BASE_DIR
test -d "`dirname $backup`" || mkdir "`dirname $backup`"
bold "Making backup in $backup\\n"
test -e "$backup" -a ! -e "$backup.gz" && gzip -f "$backup"
> "$backup"
chmod u=rw,g=,o= "$backup"
backup () {
	tar vrf "$backup" "$@"
}
[ "$Xbasedir" = "" ] && Xbasedir=/usr/X11R6; export Xbasedir
uname="`uname -sr`"
export uname
test -z "$uname" && { echo uname doesn\'t 'work !'; exit 10; }




test -d /usr/local/share || install -d -o $owner -g $Group -m 2775 /usr/local/share
install -d -o $owner -g $Group -m 2775 /usr/local/share/x-lt
install -c -o $owner -g $Group -m 775 scripts/profile /usr/local/share/x-lt
install -c -o $owner -g $Group -m 664 X11R6/Xresources /usr/local/share/x-lt
install -c -o $owner -g $Group -m 775 testUTF-8 $bindir
uname="`uname -sr`"; echo "Running on $uname..."
test -z "$uname" && { echo uname doesn\'t 'work !'; exit 10; }
has_localedef=0
if type localedef; then
	has_localedef=1
	bold 'Installing locales...'
	if test -e "/usr/share/locale/lt_LT.utf8"; then
		bold "lt_LT.UTF-8 libc locale already exists, overwrite? [Y/n]" && read a e
	else
		a='y'
	fi
	if [ "${a#[Nn]}" = "$a" ]; then
	    localedef -c -i share/i18n/locales/lt_LT -f UTF-8 lt_LT.UTF-8 2>/dev/null
	    { export LC_TIME; LC_TIME=lt_LT.UTF-8; [ "`date -d 4/1/2000 +%B`" = "balandžio" ] \
	    || localedef -i share/i18n/locales/lt_LT.UTF-8 -f share/i18n/charmaps/UTF-8 lt_LT.UTF-8 -u mnemonic.ds 2>/dev/null \
	    || localedef -i share/i18n/locales/lt_LT.UTF-8 -f share/i18n/charmaps/UTF-8 lt_LT.UTF-8 2>/dev/null; }
	    { export LC_TIME; LC_TIME=lt_LT.UTF-8; [ "`date -d 4/1/2000 +%B`" = "balandžio" ] || bold 'FAILED to install lt_LT.UTF-8 libc locale.  See README and localedef --help'; }
	fi
	# for backwards compatibility & Netscape v4 - will be removed soon
	localedef -i share/i18n/locales/lt_LT -f share/i18n/charmaps/ISO-8859-4 lt_LT.ISO_8859-4 2>/dev/null \
	|| localedef -i share/i18n/locales/lt_LT -f share/i18n/charmaps/ISO-8859-4 lt_LT.ISO_8859-4 -u mnemonic.ds 2>/dev/null
fi
if [ "${uname##[Ll][Ii][Nn][Uu][Xx]*}" = "" ]; then
	if [ _$has_localedef = _0 ]; then
		echo 'You must install localedef command (comes with libc) !'
		exit 2
	fi
elif [ "${uname##Free[Bb][Ss][Dd] [34]*}" = "" ]; then 
	installFreeBSD4
elif [ "${uname##*BSD}" = "" ]; then
	installFreeBSD4
fi
bold "Please enter your XFree (X-Window) version (4.0 or newer, 3.3.x or none)\n If you do not know, run \"X -version\" or \"XF86_VGA16 -version\"\n [4/3/n]" && read Xversion e
if [ -z "$Xversion" -o "${Xversion#4}" = "$Xversion" ]; then
	bold "Please upgrade your XFree (X-Window) to 4.0 or newer, 3.x lacks needed locale & font support\nContinue anyway (not supported)? [N/y]" && read a e
	if [ "${a#[YyTt]}" = "$a" ]; then
		exit 5
	fi
fi
if [ "${Xversion#[Nn]}" = "$Xversion"  ]; then
	Xbasedir=/usr/X11R6
	cd X11R6
	test -d $Xbasedir/lib/  || { bold $Xbasedir/lib/ not found, do you have X installed?; exit 3; }
	{ test "${PATH%%*/sbin*}" = "" && type mkfontdir 1>/dev/null 2>/dev/null; } || { bold 'Check that your PATH variable has /sbin,/usr/sbin and X (normaly /usr/X11R6/bin) directories !'; exit 4; }
	install -d $install_own -m 2775 $localXfontsdir
	install -d $install_own -m 2775 $localXfontsdir/TTF
	install -d $install_own -m 2775 $localXfontsdir/TTF.recoded
	install -d $install_own -m 2775 $localXfontsdir/Type1
	install -c $install_own -m 775 ../scripts/make_TTF_dir $bindir
	ln -sf $bindir/make_TTF_dir $localXfontsdir/TTF/make_TTF_dir
	test ! -e $localXfontsdir/TTF/fonts.alias || mv -f $localXfontsdir/TTF/fonts.alias $localXfontsdir/TTF/fonts.alias.orig 
	install -c $install_own -m 664 ../examples/config.example_for_xfsft $Xbasedir/lib/X11/fs/
	install_prompt -m 644 lib/X11/xkb/symbols/lt $Xbasedir/lib/X11/xkb/symbols/lt
	install_prompt -m 644 lib/X11/xkb/symbols/lt_std $Xbasedir/lib/X11/xkb/symbols/lt_std
	install_prompt -m 644 lib/X11/xkb/symbols/lt_p $Xbasedir/lib/X11/xkb/symbols/lt_p
	install_prompt -m 755 ../scripts/xtermu $Xbasedir/bin/xtermu
	bold '* Please look at examples of X configuration files in X11R6/ *\n'.
	cd ..
else
	Xbasedir=NO_X11
fi
export Xbasedir



#bold 'Make neccesary changes to configuration files? [Y/n]'
#read a e
#if [ "${a#[Nn]}" = "$a" ]; then
#
#  if [ "$Xbasedir" != NO_X11 ]; then
#
#    f=/etc/X11/gdm/locale.alias
#    if test -e $f; then
#	    if ! egrep -i 'Lithuanian[	 ]*lt_LT\.ISO.?8859.4' $f >/dev/null; then
#		   backup $f
#		   perl -i.orig  -e 'undef $/; $_=<>;
#		     s{^(.*?)\s*$}{$1\nLithuanian\tlt_LT.ISO_8859-4\n\n}si; print;' $f
#	    fi
#    fi
#
#  fi # NO_X11
#
#fi # changes to config files

if [ "$Xbasedir" != NO_X11 ]; then
while :; do
   bold 'If you want to install TrueType fonts, put all *.ttf files (or make symlinks)\n in /usr/local/lib/X11/fonts/TTF/ and press Y. \nDirectory itself must have write access. \nSome TTF fonts you can download from http://www.kada.lt/litwin/ \nPlease use TTFs with Unicode tables (i.e. not from Windows 3.1).\n[Y/n]'

   read a e
   if [ "${a#[Nn]}" = "$a" ]; then
	ls	/usr/local/lib/X11/fonts/TTF/*.[Tt][Tt][f] >/dev/null || continue
	touch	/usr/local/lib/X11/fonts/TTF/tmp.tmp || continue
	rm	/usr/local/lib/X11/fonts/TTF/tmp.tmp

	if ! type ttmkfdir; then
	  if [ "${uname##*[Ll]inux*}" = "" ]; then
		  libc_v="`ldd /usr/bin/true /usr/bin/man 2>&1`"
		  cd "$BASE_DIR"/../ttmkfontdir/
		  if [ "${libc_v#*libc.so.5}" != "$libc_v" ]; then
			  install -c -m 775 ttmkfdir.linuxbin.libc5 /usr/X11R6/bin/ttmkfdir
		  elif [ "${libc_v#*libc.so.6}" != "$libc_v" ]; then
			  install -c -m 775 ttmkfdir.linuxbin.glibc2 /usr/X11R6/bin/ttmkfdir
		  else
			  libc_v=
		  fi
	  fi
	  test -z "$libc_v" && while :; do
		  bold 'Go to ./ttmkfontdir, make it and install somewhere on the PATH. \nIf your are on *BSD go to the ports/x11-fonts/ttmkfdir and make install \nPress <Return> to continue after that..'
		  read a
		  type ttmkfdir && break
	  done
	fi
	cd /usr/local/lib/X11/fonts/TTF
	"$BASE_DIR/make_TTF_dir" -lt

	if type chkfontpath 2>/dev/null; then
		echo 'Removing old /usr/local/lib/X11/fonts/ directory from fontpath'
		chkfontpath --remove /usr/local/lib/X11/fonts 2>/dev/null >/dev/null
	else
	        bold 'Done with TTF.  Now change XF86Config and/or \n/usr/X11R6/lib/fs/config.  See README for details.\n'
	fi
   fi
   break
done
fi # NO_X11

bold 'If you still have Netscape browser v4.5 or newer v4.x I can add Baltic encodings to it \ninstead of Greek.  Do it? [Y/n]'
read a e
if [ "${a#[Nn]}" = "$a" ]; then
	perl "$BASE_DIR/NC_baltic"
fi

[ "${uname##FreeBSD*}" = "" ] && bold 'Add to kernel config file:\n	options         "SC_MOUSE_CHAR=0x03"		and recompile.\n'
bold 'Now add Lithuanian keyboard layout to XF86Config as in XFree86/lib/X11/xkb/symbols/lt; \nread README and reboot.\nDo not run graphical login until you are sure your X can start - use startx !\n'

